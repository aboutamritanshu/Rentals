---
name: Custom issue template
about: Describe this issue template's purpose here.
title: 'Issue of #StateTypeHere'
labels: help wanted, just opened
assignees: ''

---

**Type of issue/enquiry**
- Few words highlighting Issue Domain

**Description**
- Briefly expressed issue or any help wanted


**Screenshots (if any)**
- Add URL here

 **Other Specifications**
- Steps to recreate
- Hardware/software specification
