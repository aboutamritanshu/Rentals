---
name: Feature request
about: Suggest an idea for this project
title: "#Name Feature"
labels: enhancement, just opened
assignees: ''

---

**Feature Description**
- Add the ideation here

**Problem it would solve**
- Problems that would likely be solved by feature inclusion

**Suggested Solution/ Changes**
- [ ] Change 1
- [x] Change 2

**Additional context**
Add any other context or screenshots about the feature request here.
